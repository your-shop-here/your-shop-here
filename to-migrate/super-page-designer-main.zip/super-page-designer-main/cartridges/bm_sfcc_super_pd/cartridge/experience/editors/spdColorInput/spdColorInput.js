'use strict';

module.exports.init = function (editor) {};
