'use strict';

const Site = require('dw/system/Site');
const HTTPClient = require('dw/net/HTTPClient');
const URLUtils = require('dw/web/URLUtils');

module.exports.init = function (editor) {};
