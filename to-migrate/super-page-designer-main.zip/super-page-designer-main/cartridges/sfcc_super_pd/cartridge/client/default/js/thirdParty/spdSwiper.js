import Swiper from 'swiper';
import { Autoplay, EffectFade } from 'swiper/modules';

Swiper.use([Autoplay, EffectFade]);

window.SPDSwiper = Swiper;
