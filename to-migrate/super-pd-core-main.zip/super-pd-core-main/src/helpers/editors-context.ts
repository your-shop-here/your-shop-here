// This file contains runtime context for editors
const editorsContext = () => window.EditorsContext;

export default editorsContext;
